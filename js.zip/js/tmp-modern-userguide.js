$(document).ready(function () {
    $("#tmpmodernuserguide").html("");

    $("#tmpmodernuserguide").append( "<ul>"+
        "<li data-nav-id='../Introduction' title='Introduction' class='sidelist'>"+
        "<a href='/employee-vacation-tracker-time-off-manager/modern/user/introduction/'>"+
        "Introduction"+
        "</a>"+
        "</li>"+
        "<li data-nav-id='../Introduction' title=Getting-Started class='sidelist'>"+
            "<a href='/employee-vacation-tracker-time-off-manager/modern/user/getting-started/'>"+
                "Getting Started"+
            "</a>"+
            "</li>"+
    
        "<li data-nav-id='../Home-page' title=Home-page class=sidelist>"+
            "<a href='/employee-vacation-tracker-time-off-manager/modern/user/home-page/'>"+
                "Home Page"+
            "</a>"+
            "</li>"+
        
        "<li data-nav-id='../ HR-actions' title= HR-actions class=sidelist>"+
        "<a href='/employee-vacation-tracker-time-off-manager/modern/user/user-interface/'>"+
          "User Interface"+
        "</a>"+
        "</li>"+
    
         "<li data-nav-id='../user' title=user class='sidelist'>"+
                "<a href='/employee-vacation-tracker-time-off-manager/modern/user/help/'>"+
                "Help"+
                "</a>"+
            "</li>"+
        "</ul>")
                                           
                                        });

                                        