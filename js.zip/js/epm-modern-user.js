$(document).ready(function () {
    $("#empmodernuser").html("");

    $("#empmodernuser").append( "<li data-nav-id='./installation/requirments/' title=Introduction class=sidelist>"+
    "<a href='/employee-performance-management/modern/user/introduction/'>"+
    "Introduction"+
    "</a>"+  
"</li>"+

"<li data-nav-id='./installation/requirments/' title= 'Home Page' class=sidelist>"+
    "<a href='/employee-performance-management/modern/user/home/'>"+
    "Home Page"+
    "</a>"+  
"</li>"+

"<li class='dropdownicon sidelist' title='Self Review'>"+
"<a class='qwe' href='/employee-performance-management/modern/user/self-review/'>"+
    "Self Review"+
    "</a>"+ 
    "<img src='./down-arrow-svgrepo-com.svg'  class='imageIconmodernuser aside_dropdown_icon'>"+
"</li>"+

"<li data-nav-id='./installation/requirments/' class='sidelist dropdown_romove_dot'>"+
    
    
    "<ul class='sidenavSub-topics aside_dropdown_list active'>"+
        "<li data-nav-id='../General' title= 'Review'  class=sidelist>"+
          "<a href='/employee-performance-management/modern/user/self-review/#review'>"+
            "Review"+
            "</a>"+
            "</li>"+

            "<li data-nav-id='../General' title='Summary and Plan'  class=sidelist>"+
                "<a href='/employee-performance-management/modern/user/self-review/#summary-and-plan'>"+
                    "Summary and Plan"+
                  "</a>"+
                  "</li>"+

    "</ul>"+

"</li>"+


"<li class='dropdownicon sidelist' title='360 Feedback'>"+
    "<a class='qwe' href='/employee-performance-management/modern/user/feedback/'>"+
        "360 Feedback"+
     "</a>"+ 
    "<img src='./down-arrow-svgrepo-com.svg'  class='imageIconmodernuser aside_dropdown_icon'>"+
"</li>"+
"<li data-nav-id='./installation/requirments/'  class='sidelist dropdown_romove_dot'>"+
   
        
    "<ul class='sidenavSub-topics aside_dropdown_list active'>"+
    "<li data-nav-id='../General' title='Feedback Request'  class=sidelist>"+
                "<a href='/employee-performance-management/modern/user/feedback/#feedback-request'>"+
                    "Feedback Request"+
                  "</a>"+
            "</li>"+
            "<li data-nav-id='../General' title='Recieved'  class=sidelist>"+
            "<a href='/employee-performance-management/modern/user/feedback/#received'>"+
            "Recieved"+
                "</a>"+
            "</li>"+

            "<li data-nav-id='../General' title='Given'  class=sidelist>"+
                "<a href='/employee-performance-management/modern/user/feedback/#given'>"+
                    "Given"+
                  "</a>"+
            "</li>"+

            "<li data-nav-id='../General' title='Action'  class=sidelist>"+
                "<a href='/employee-performance-management/modern/user/feedback/#action'>"+
                    "Action"+
                  "</a>"+
            "</li>"+

            

    "</ul>"+

"</li>")
                                           
                                        });

                                        