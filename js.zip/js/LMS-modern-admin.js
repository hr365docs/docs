$(document).ready(function () {
    $("#lmsmodernadmin").html("");

    $("#lmsmodernadmin").append("<li data-nav-id='./Settings/' title=Introduction class=sidelist>"+

    "<a href='/LMS/modern/admin/introduction/'>"+
       " Introduction"+
   " </a>"+
"</li>"+
// "<li data-nav-id='./Settings/' title='Architecture Diagram' class=sidelist>"+

//     "<a href='/contract-management/modern/admin/architecture-diagram/'>"+
//         "Architecture Diagram"+
//   "</a>"+

// "</li>"+
"<li data-nav-id='./Settings/' title='Home Page' class=sidelist>"+

    "<a href='/LMS/modern/admin/home/'>"+
        "Home Page"+
  "</a>"+

"</li>"+
"<li class='dropdownicon sidelist' title='Theme'>" +
"<a href='/LMS/modern/admin/Theme/'>" +
"Theme" +
"</a>" +

"</li>" +

"<li data-nav-id='../advanced/' title=Help class='sidelist dropdown_romove_dot'>" +





   
"<li class='dropdownicon sidelist' title=Settings>"+
    "<a  class='qwe' href='/LMS/modern/admin/setting/'>"+
        "Settings"+
    "</a>"+
    "<img src='/down-arrow-svgrepo-com.svg'  class='imageIconmodernuser aside_dropdown_icon'>"+
"</li>"+

"<li data-nav-id='./Settings/'  class='sidelist dropdown_romove_dot'>"+
    "<ul class='sidenavSub-topics aside_dropdown_list active'>"+
        
       " <ul>"+
           
           " <li data-nav-id='./General-Settings/' title='General Settings' class='sidelist'>"+
            "<a href='/LMS/modern/admin/setting/general-setting'>"+
           " General Settings"+
            "</a>"+
            "</li>"+


            "<li data-nav-id='./General-Settings/' title='App Users' class='sidelist'>"+
            "<a href='/LMS/modern/admin/setting/App-Users'>"+
           " App-Users"+
            "</a>"+
            "</li>"+

            "<li data-nav-id='./General-Settings/' title='Notifications' class='sidelist'>"+
            "<a href='/LMS/modern/admin/setting/Notification'>"+
           " Notifications"+
            "</a>"+
            "</li>"+

            "<li data-nav-id='./General-Settings/' title='Assessments' class='sidelist'>"+
            "<a href='/LMS/modern/admin/setting/Assessment'>"+
           " Assessments"+
            "</a>"+
            "</li>"+

            "<li data-nav-id='./General-Settings/' title='Courses' class='sidelist'>"+
            "<a href='/LMS/modern/admin/setting/Courses'>"+
           " Courses"+
            "</a>"+
            "</li>"+




            " </ul>"+
            " </ul>"+
            " </li>"+



           "<li class='dropdownicon sidelist' title=Help>"+
    "<a  class='qwe' href='/LMS/modern/admin/help/'>"+
        "Help"+
    "</a>"+
    "<img src='../../down-arrow-svgrepo-com.svg'  class='imageIconmodernuser aside_dropdown_icon'>"+
"</li>"+

"<li data-nav-id='./Settings/'  class='sidelist dropdown_romove_dot'>"+
    "<ul class='sidenavSub-topics aside_dropdown_list active'>"+
        
       " <ul>"+
           
           " <li data-nav-id='./General-Settings/' title='Product Activation' class='sidelist'>"+
            "<a href='/LMS/modern/admin/help/#product-activation'>"+
           " Product Activation"+
            "</a>"+
            "</li>"+
            "</ul>"+
            "<ul>"+
            "</li>"


            





)
                                           

}
);
