$(document).ready(function () {
    $("#ETuseradmin").html("");

    $("#ETuseradmin").append("<li data-nav-id='./Settings/' title=Introduction class=sidelist>" +

        "<a href='/Expense-tracker/modern/user/introduction/'>" +
        " Introduction" +
        " </a>" +
        "</li>" +
     

        "</li>" +
        "<li data-nav-id='./Settings/' title='Home Page' class=sidelist>" +

        "<a href='/Expense-tracker/modern/user/home/'>" +
        "Home Page" +
        "</a>" +

        "</li>" +
        "<li data-nav-id='./Settings/' title='Home Page' class=sidelist>" +

        "<a href='/Expense-tracker/modern/user/Report'>" +
        "Report" +
        "</a>" +

        "</li>" +
        "<li data-nav-id='./Settings/' title='Home Page' class=sidelist>" +

        "<a href='/Expense-tracker/modern/user/Help/'>" +
        "Help" +
        "</a>" +

        "</li>" +

        "</li>")

});
