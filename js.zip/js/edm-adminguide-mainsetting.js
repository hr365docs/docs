$(document).ready(function () {
    $('#modernadminmainsetting').html('');

    $('#modernadminmainsetting').append("<li data-nav-id='../advanced/' title=General class='sidelist' >"+
                                                 
    "<div class='dropdownicon'>"+
      "<a  class='qwe' href='/sharepoint-employee-directory/modern/admin/settings/general/'>"+
        "General"+
      "</a>"+
      "<img src='../../../down-arrow-svgrepo-com.svg' class='imageIcongeneral aside_dropdown_icon' '>"+
    "</div>"+

      "<ul class='sidenavSub-topics aside_dropdown_list' id='edmmoderngeneral'>"+

        
      "</ul>"+

    "</li>"+
  

  "<li data-nav-id='../Exclude-Options/' title='Exclude Options' class='sidelist'>"+
      "<a href='/sharepoint-employee-directory/modern/admin/settings/exclude-options/'>"+
          "Exclude Options"+
      "</a>"+
  "</li>"+

  "<li data-nav-id='../views/' title=Views class='sidelist'>"+
      "<a href='/sharepoint-employee-directory/modern/admin/settings/views/'>"+
          "Views"+
      "</a>"+
  "</li>"+

  "<li data-nav-id='../advanced/' title=Advanced class='sidelist'>"+

    "<div class='dropdownicon'>"+
      "<a href='/sharepoint-employee-directory/modern/admin/settings/advanced/'>"+
        "Advanced"+
      "</a>"+
      "<img src='../../../down-arrow-svgrepo-com.svg' class='imageIconadvanced aside_dropdown_icon' '>"+
    "</div>"+

      "<ul class='sidenavSub-topics aside_dropdown_list' id='modernsettingedm'>"+
        
       
        "</ul>"+
    "</li>"
 )
                                           
                                        });


                                     
                                        