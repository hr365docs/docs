$(document).ready(function() {
    $(".sidensvbarlink").html("");

    $(".sidensvbarlink").append("<li data-nav-id=https://github.com/hr365docs/My-project.git/installation/requirments/" +
        "title=Introduction class='sidelist'>" +
        "<a href='/sharepoint-employee-directory/classic/user/intoduction/'>" +
        "Introduction" +
        "</a>" +
        "</li>" +
        "<ul class='ml-15 sidenavSub-topics'>" +
        "<li data-nav-id=https://github.com/hr365docs/My-project.git/installation/requirments/" +
        "title=Getting started class='sidelist gettingstartedlink'>" +
        "<a href='/sharepoint-employee-directory/classic/user/getting-started/'>Getting started</a>" +
        "</li>" +
        "<li data-nav-id=https://github.com/hr365docs/My-project.git/user_profile/requirments/" +
        "title=Profile class='sidelist'>" +
        "<a href='/sharepoint-employee-directory/classic/user/profile/'>Managing User Profile</a>" +
        "</li>" +
        "<li class='dropdownicon sidelist'>"+
            "<a class='qwe' href='/sharepoint-employee-directory/classic/user/user-interface/'>User interface</a>" +
            "<img src='./down-arrow-svgrepo-com.svg'  class='imageIcon aside_dropdown_icon' '>" +
        "</li>"+
        "<li data-nav-id=https://github.com/hr365docs/My-project.git/installation/requirments/" +
        "title=User interface class='sidelist dropdown_romove_dot' >" +
        "<ul class='ml-15 sidenavSub-topics aside_dropdown_list' id='userinterecenavbar'>" +

        "<li data-nav-id=https://github.com/hr365docs/My-project.git/installation/requirments/" +
        "title=Home class='sidelist'>" +
        "<a href='/sharepoint-employee-directory/classic/user/user-interface/#user-home-page'>Home Page</a>" +
        "</li>" +
        "<li data-nav-id=https://github.com/hr365docs/My-project.git/installation/requirments/" +
        "title=Search class='sidelist'>" +
        "<a href='/sharepoint-employee-directory/classic/user/user-interface/#user-search-page'>Search</a>" +

        "</li>" +
        "<li data-nav-id=https://github.com/hr365docs/My-project.git/installation/requirments/" +
        "title=Views class='sidelist'>" +
        "<a href='/sharepoint-employee-directory/classic/user/user-interface/#user-view-page'>Views</a>" +
        "</li>" +
        "</ul>" +
        "</li>" +

        "</ul>" +
        "</li>");



});










//                 $(".navbar-nav.ml-auto").append("<li class='nav-item'>"+
//                 "<a class='nav-link text-dark timeofmanagerlink' href='../time-off-manager/'>Time-Off Manager</a>"+
//                 "</li>");


//                 $(".navbar-nav.ml-auto").append("<li class='nav-item'>"+
//                 "<a class='nav-link text-dark timesheetlink' href='../timesheets/'>Timesheet</a>"+
//             "</li>");


//             $(".navbar-nav.ml-auto").append("<li class='nav-item'>"+
//             "<a class='nav-link text-dark onboardinglink' href='../employee-on-boarding/'>Employee On-boarding</a>"+
//             "</li>");

//             $(".navbar-nav.ml-auto").append("<li class='nav-item'>"+
//             "<a class='nav-link text-dark performancelink' href='../employee-performance-management/'>Performance Management</a>"+
//             "</li>");

//             $(".navbar-nav.ml-auto").append("<li class='nav-item'>"+
//             "<a class='nav-link text-dark performancelink' href='../contact/'>Contact</a>"+
//             "</li>");




// window.addEventListener("load",()=>{
//     console.log(window.location.href.substring(window.location.href.lastIndexOf('/') - 2));
// })