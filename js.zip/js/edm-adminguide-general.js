$(document).ready(function () {
    $('#edmmoderngeneral').html('');

    $('#edmmoderngeneral').append("<li  data-nav-id='../advanced/' title='Search filters' class='sidelist'>"+
    "<a href='/sharepoint-employee-directory/modern/admin/settings/general/#search-filter'>Search filters</a>"+
  "</li>"+

  "<li  data-nav-id='../advanced/' title='Allow users to export directory' class='sidelist'>"+
    "<a href='/sharepoint-employee-directory/modern/admin/settings/general/#allow-user-export-directory'>Show or Hide modules</a>"+
  "</li>"+

  "<li  data-nav-id='../advanced/' title='Language selection' class='sidelist'>"+
    "<a href='/sharepoint-employee-directory/modern/admin/settings/general/#language-selection-as-browser'>Language selection as browser default language</a>"+
  "</li>"+
  

  "<li  data-nav-id='../advanced/' title='Language selection' class='sidelist '>"+
    "<a href='/sharepoint-employee-directory/modern/admin/settings/general/#language-selection'>Language selection in case browser default language is not detected</a>"+
  "</li>"+

  "<li  data-nav-id='../advanced/' title=' Update users role and permissions' class='sidelist'>"+
    "<a href='/sharepoint-employee-directory/modern/admin/settings/general/#update-roles'>Hide Sharepoint Page's Default Components</a>"+
  "</li>"+

  "<li  data-nav-id='../advanced/' title=' Update users department' class='sidelist '>"+
    "<a href='/sharepoint-employee-directory/modern/admin/settings/general/#update-department'>Role and permissions"+
    "</a>"+
  "</li>"+
  "<li  data-nav-id='../advanced/' title=' Update job title ' class='sidelist'>"+
    "<a href='/sharepoint-employee-directory/modern/admin/settings/general/#Filterattribute'>Filter Attributes"+
    "</a>"+
  "</li>"+
  "<li  data-nav-id='../advanced/' title=' Update users location  ' class='sidelist'>"+
    "<a href='/sharepoint-employee-directory/modern/admin/settings/general/#Map-external-list'> Map external list  </a>"+
  "</li>"+
  "<li  data-nav-id='../advanced/' title='Collaboration ' class='sidelist '>"+
    "<a href='/sharepoint-employee-directory/modern/admin/settings/general/#AzureStorageConfiguration'>Azure Storage Configuration </a>"+
  "</li>"+
  "<li  data-nav-id='../advanced/' title='Custom link ' class='sidelist'>"+
    "<a href='/sharepoint-employee-directory/modern/admin/settings/general/#Syncemployeeprofileimagesfrom'>Sync employee profile images from</a>"+
  "</li>"+
  "<li  data-nav-id='../advanced/' title='Custom link ' class='sidelist'>"+
  "<a href='/sharepoint-employee-directory/modern/admin/settings/general/#Recordstoload'>Records to load </a>"+
"</li>"+
"<li  data-nav-id='../advanced/' title='Custom link ' class='sidelist'>"+
"<a href='/sharepoint-employee-directory/modern/admin/settings/general/#Brandlogo'>Brand logo </a>"+
"</li>"+
"<li  data-nav-id='../advanced/' title='Custom link ' class='sidelist'>"+
"<a href='/sharepoint-employee-directory/modern/admin/settings/general/#Birthdayandanniversarytemplates'>Birthday and anniversary templates </a>"+
"</li>"+"<li  data-nav-id='../advanced/' title='Custom link ' class='sidelist'>"+
"<a href='/sharepoint-employee-directory/modern/admin/settings/general/#GCCTenant'>GCC Tenant</a>"+
"</li>"+
"<li  data-nav-id='../advanced/' title='Custom link ' class='sidelist'>"+
"<a href='/sharepoint-employee-directory/modern/admin/settings/general/#Employeeinfopage'>Employee info page</a>"+
"</li>"+
"<li  data-nav-id='../advanced/' title='Custom link ' class='sidelist'>"+
"<a href='/sharepoint-employee-directory/modern/admin/settings/general/#Profilecardcustomurlicon'>Profile card custom url icon</a>"+
"</li>"+
"<li  data-nav-id='../advanced/' title='Custom link ' class='sidelist'>"+
"<a href='/sharepoint-employee-directory/modern/admin/settings/general/#Homepagecustomurl'>Home page custom url</a>"+
"</li>"+
"<li  data-nav-id='../advanced/' title='Custom link ' class='sidelist'>"+
"<a href='/sharepoint-employee-directory/modern/admin/settings/general/#orgChart'>Organization chart type</a>"+
"</li>"


  
 )
                                           
                                        });

                                     

                                        