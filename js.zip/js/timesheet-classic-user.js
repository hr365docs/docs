$(document).ready(function () {
    $("#timesheetclassicuser").html("");

    $("#timesheetclassicuser").append( "<li data-nav-id='./installation/requirments/' title='Introduction' class=sidelist>"+
    "<a href='/online-timesheet-software/classic/user/intoduction/'>"+
    "Introduction"+
    "</a>"+  
"</li>"+
"<li data-nav-id='./installation/requirments/' title='Getting Started' class=sidelist>"+
    "<a href='/online-timesheet-software/classic/user/getting-started/'>"+
    "Getting Started"+
"</a>"+  
"</li>"+

"<li data-nav-id='./installation/requirments/' title='Home Page' class=sidelist>"+
    "<a href='/online-timesheet-software/classic/user/home-page/'>"+
    "Home Page"+
    "</a>"+  
"</li>"+
"<li data-nav-id='./installation/requirments/' title='Reports' class=sidelist>"+
    "<a href='/online-timesheet-software/classic/user/reports/'>"+
    "Reports"+
    "</a>"+  
"</li>"+
"<li data-nav-id='./installation/requirments/' title='User Interface' class=sidelist>"+
    "<a href='/online-timesheet-software/classic/user/user-interface/'>"+
    "User Interface"+
    "</a>"+  
"</li>"+

"<li data-nav-id='./installation/requirments/' title='Help' class=sidelist>"+
    "<a href='/online-timesheet-software/classic/user/help/'>"+
    "Help"+
    "</a>"+  
"</li>")
                                           
                                        });

                                        