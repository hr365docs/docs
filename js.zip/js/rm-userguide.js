$(document).ready(function () {
    $("#rmmmodernuser").html("");

    $("#rmmmodernuser").append( "<li data-nav-id='./installation/requirments/' title=Introduction class=sidelist>"+
    "<a href='/RM365/modern/user/introduction/'>"+
    "Introduction"+
    "</a>"+  
"</li>"+

"<li data-nav-id='./installation/requirments/' title= 'Home Page' class=sidelist>"+
    "<a href='/RM365/modern/user/home/'>"+
    "Home Page"+
    "</a>"+  
"</li>"+
"<li class='dropdownicon sidelist' title='Draft'>"+
    "<a class='qwe' href='/RM365/modern/user/draft/'>"+
        "Draft"+
     "</a>"+ 
  
"</li>"+


"<li class='dropdownicon sidelist' title='Help'>"+
    "<a class='qwe' href='/RM365/modern/user/help/'>"+
        "Help"+
     "</a>"+ 
  
"</li>"

)
                                           
                                        });

                                        