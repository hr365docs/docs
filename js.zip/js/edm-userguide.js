$(document).ready(function () {
    $("#edmmodernuserguide").html("");

    $("#edmmodernuserguide").append("<li data-nav-id='https://github.com/hr365docs/My-project.git/installation/requirments/' title=Introduction class=sidelist>"+
    "<a href='/sharepoint-employee-directory/modern/user/introduction/'>"+
      "Introduction"+
    "</a>"+
    "</li>"+
    "<ul class='ml-15 sidenavSub-topics'>"+
      "<li class='sidelist' title='Getting started'>"+
        "<a href='/sharepoint-employee-directory/modern/user/getting-started/'>Getting started</a>"+
      "</li>"+
      "<li class='sidelist' title='Managing User Profile'>"+
        "<a href='/sharepoint-employee-directory/modern/user/managing-user-profile/'>Managing User Profile</a>"+
      "</li>"+

      "<li class='dropdownicon sidelist' title='User Interface'>"+
      "<a class='qwe' href='/sharepoint-employee-directory/modern/user/user-interface/'>User Interface</a>"+
      "<img src='./down-arrow-svgrepo-com.svg'  class='imageIconmodernuser aside_dropdown_icon''>"+
  "</li>"+

      "<li data-nav-id=https://github.com/hr365docs/My-project.git/installation/requirments/"+
        "title=User Interface class='sidelist dropdown_romove_dot'>"+

        "<ul class='ml-15 sidenavSub-topics aside_dropdown_list' id='modernuserguide'>"+
          "<li  class='sidelist' title=Home>"+
            "<a href='/sharepoint-employee-directory/modern/user/user-interface/#home-page'>Home Page</a>"+

          "</li>"+
          
          "<li  class='sidelist' title=Search>"+
            "<a href='/sharepoint-employee-directory/modern/user/user-interface/#search'>Search</a>"+

          "</li>"+
          "<li  class='sidelist' title=Views>"+
            "<a href='/sharepoint-employee-directory/modern/user/user-interface/#views'>Views</a>"+

          "</li>"+

          "<li  class='sidelist' title=Help>"+
            "<a href='/sharepoint-employee-directory/modern/user/user-interface/#help'>Help</a>"+

          "</li>"+

        "</ul>"+
      "</li>"+

  "</li>")
                                           
                                        });

                                        