$(document).ready(function () {
    $("#clmmodernadmin").html("");

    $("#clmmodernadmin").append("<li data-nav-id='./Settings/' title=Introduction class=sidelist>"+

    "<a href='/contract-management/modern/admin/introduction/'>"+
       " Introduction"+
   " </a>"+
"</li>"+
"<li data-nav-id='./Settings/' title='Architecture Diagram' class=sidelist>"+

    "<a href='/contract-management/modern/admin/architecture-diagram/'>"+
        "Architecture Diagram"+
  "</a>"+

"</li>"+
"<li data-nav-id='./Settings/' title='Home Page' class=sidelist>"+

    "<a href='/contract-management/modern/admin/home-page/'>"+
        "Home Page"+
  "</a>"+

"</li>"+
"<li class='dropdownicon sidelist' title='Help'>" +
"<a href='/contract-management/modern/admin/dashboard/'>" +
"Dashboard" +
"</a>" +
"<img src='../../down-arrow-svgrepo-com.svg' class='imageIconadvanced aside_dropdown_icon' '>" +
"</li>" +

"<li data-nav-id='../advanced/' title=Help class='sidelist dropdown_romove_dot'>" +



"<ul class='sidenavSub-topics aside_dropdown_list' id='modernsettingedm'>" +
"<li  data-nav-id='../advanced/' title='Configure SharePoint API permissions' class='sidelist'>" +
"<a href='/contract-management/modern/admin/dashboard/#Contract'>Contract</a>" +
"</li>"+
"<li  data-nav-id='../advanced/' title='Configure SharePoint API permissions' class='sidelist'>" +
"<a href='/contract-management/modern/admin/dashboard/#Request'>Request</a>" +
"</li>"+
"</ul>"+

"<li data-nav-id='./Settings/' title=Reports class=sidelist>"+

"<a href='/contract-management/modern/admin/reports/'>"+
" Reports"+
    "</a>"+
"</li>"+



"<li data-nav-id='./Settings/' title=Reports class=sidelist>"+

"<a href='/contract-management/modern/admin/administration/'>"+
" Administration"+
    "</a>"+
"</li>"+



   
"<li class='dropdownicon sidelist' title=Settings>"+
    "<a  class='qwe' href='/contract-management/modern/admin/settings/'>"+
        "Settings"+
    "</a>"+
    "<img src='../../down-arrow-svgrepo-com.svg'  class='imageIconmodernuser aside_dropdown_icon'>"+
"</li>"+

"<li data-nav-id='./Settings/'  class='sidelist dropdown_romove_dot'>"+
    "<ul class='sidenavSub-topics aside_dropdown_list active'>"+
        
       " <ul>"+
           
           " <li data-nav-id='./General-Settings/' title='Users, Roles and Permissions' class='sidelist'>"+
            "<a href='/contract-management/modern/admin/settings/#users-roles-permissions'>"+
           " Users, Roles and Permissions"+
            "</a>"+
            "</li>"+
          
           " <li data-nav-id='./Custom-Emails/' title=Integrations class='sidelist'>"+
                "<a href='/contract-management/modern/admin/settings/#integrations'>"+
                "Integrations"+
               " </a>"+
            "</li>"+

            "<li data-nav-id='./Column-Setting/' title=Contract Fields class='sidelist'>"+
           "<a href='/contract-management/modern/admin/settings/#Autonumbering'>"+
           " Auto Numbering"+
           "</a>"+
           "</li>"+

           " <li data-nav-id='./Custom-Emails/' title=Users class='sidelist'>"+
                "<a href='/contract-management/modern/admin/settings/#Generalsetting'>"+
                "General Setting"+
               " </a>"+
            "</li>"+
        //     " <li data-nav-id='./Custom-Emails/' title=Users class='sidelist'>"+
        //     "<a href='/contract-management/modern/admin/settings/#Notification'>"+
        //     "Notification"+
        //    " </a>"+
        // "</li>"+
        " <li data-nav-id='./Custom-Emails/' title=Users class='sidelist'>"+
        "<a href='/contract-management/modern/admin/settings/#Feature'>"+
        "Feature"+
       " </a>"+
    "</li>"+
        
    " <li data-nav-id='./Custom-Emails/' title=Users class='sidelist'>"+
    "<a href='/contract-management/modern/admin/settings/#Contractfiels'>"+
    "Contract Field"+
   " </a>"+
"</li>"+


       
        "</ul>"+
    "</ul>"+

"</li>"+



"<li class='dropdownicon sidelist' title='Help'>" +
"<a href='/contract-management/modern/admin/help/'>" +
"Help" +
"</a>" +
"<img src='../../down-arrow-svgrepo-com.svg' class='imageIconadvanced aside_dropdown_icon' '>" +
"</li>" +

"<li data-nav-id='../advanced/' title=Help class='sidelist dropdown_romove_dot'>" +



"<ul class='sidenavSub-topics aside_dropdown_list' id='modernsettingedm'>" +
"<li  data-nav-id='../advanced/' title='Configure SharePoint API permissions' class='sidelist'>" +
"<a href='/contract-management/modern/admin/help/#product-activation'>Product Activation</a>" +
"</li>" )
                                           
});
