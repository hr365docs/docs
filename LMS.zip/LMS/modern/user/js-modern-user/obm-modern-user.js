$(document).ready(function() {
    $("#obm-modern-user").html("");
    $("#obm-modern-user").append(
        "<ul>"+
        " <li data-nav-id='./installation/requirments/' title=Introduction class=sidelist>"+
         "<a href='/sharepoint-employee-onboarding/modern/user/introduction/'> Introduction </a>"+
         "</li>"+
         "<li data-nav-id=https://github.com/hr365docs/My-project.git/installation/requirments/ title='Getting Started' class=sidelist>"+
         "<a href='/sharepoint-employee-onboarding/modern/user/getting-started/'>Getting Started</a>"+
         "<li data-nav-id='./installation/requirments/' title=Home Page class=sidelist>"+
         "<a href='/sharepoint-employee-onboarding/modern/user/home-page/'> Home Page </a>"+
         "</li>"+

         "<li data-nav-id='./installation/requirments/' title=Home Page class=sidelist>"+
         "<a href='/sharepoint-employee-onboarding/modern/user/Ess-Portal/'> Ess Portal </a>"+
         "</li>"+
         
         
     
         "<li class='dropdownicon sidelist'  title='User Interface'>"+
         "<a class='qwe'  href='/sharepoint-employee-onboarding/modern/user/user-interface/'> User Interface </a>"+
         "<img class='helpdesk-img aside_dropdown_icon' src='/sharepoint-employee-onboarding/classic/user/js-user/down-arrow-svgrepo-com.svg'>"+
         "</li>"+
         "<li data-nav-id='./installation/requirments/' class='sidelist dropdown_romove_dot'>"+
         "<ul class='sidenavSub-topics aside_dropdown_list'>"+
          "<li data-nav-id='../General' title='Updated Profiles' class='sidelist'>"+
          "<a href='/sharepoint-employee-onboarding/modern/user/user-interface/#update-profiles'> Update Profiles </a>"+
           "</li>"+
           "<li data-nav-id='../General' title=' Update Details' class=sidelist>"+
            "<a href='/sharepoint-employee-onboarding/modern/user/user-interface/#update-details'> Update Details </a>"+
             "</li>"+
             "<li data-nav-id='../General' title='Upload Documents' class=sidelist>"+
              "<a href='/sharepoint-employee-onboarding/modern/user/user-interface/#upload-documents'> Upload Documents </a>"+
              "</li>"+
              "</ul>"+
              "</li>"+
              "</li>"+
              "</ul>")
})