$(document).ready(function () {
    $("#hdm-admin-aside").html("");
    $("#hdm-admin-aside").append(
        "<li data-nav-id='./installation/requirments/' title=Introduction class='sidelist'>"+
        "<a href='/online-timesheet-software/modern/admin/introduction/'>Introduction</a>"+
        "</li>"+

        "<li data-nav-id='./installation/requirments/' title='Architecture Diagram' class='sidelist'>"+
        "<a href='/online-timesheet-software/modern/admin/architecture-diagram/'>Architecture Diagram</a>"+
        "</li>"+
        "<li data-nav-id='./installation/requirments/' title='Home Page' class='sidelist'>"+
        "<a href='/online-timesheet-software/modern/admin/home-page/'>Home Page</a>"+
        "</li>"+
        "<li data-nav-id='./Settings/' title=Reports class='sidelist'>"+
        "<a href='/online-timesheet-software/modern/admin/reports/'>Reports</a>"+
        "</li>"+
      
        "<li data-nav-id='./Adminstration' title=Introduction class='sidelist'>"+
        "<a href='/online-timesheet-software/modern/admin/administration/'>Administration</a>"+
        "</li>"+


        "<li class='dropdownicon sidelist'>"+
        "<a class='qwe' href='/online-timesheet-software/modern/admin/settings/'>Settings</a>"+
        "<img class='helpdesk-img aside_dropdown_icon_setting' src='/online-timesheet-software/modern/admin/hdm-admin-aside-js/down-arrow-svgrepo-com.svg'>"+
        "</li>"+

       "<li data-nav-id='./Settings/' title='Settings'  class='sidelist dropdown_romove_dot'>"+
        "<ul class='sidenavSub-topics aside_dropdown_list_setting'>"+
        "<li>"+
        "<a class='qwe' href='/online-timesheet-software/modern/admin/settings/general/'>General</a>"+
        
        "</li>"+

        "<li>"+
        "<a class='qwe' href='/online-timesheet-software/modern/admin/settings/role/'>Users</a>"+
        
        "</li>"+

        "<li>"+
        "<a class='qwe' href='/online-timesheet-software/modern/admin/settings/features/'>Features</a>"+
        
        "</li>"+

        

        "<li>"+
        "<a class='qwe' href='/online-timesheet-software/modern/admin/settings/notification/'>Notification</a>"+
        
        "</li>"+
        
        "<li>"+
        "<a class='qwe' href='/online-timesheet-software/modern/admin/settings/email-template/'>Email Template</a>"+
        
        "</li>"+
        "<li>"+
        "<a class='qwe' href='/online-timesheet-software/modern/admin/settings/integration/'>Integration</a>"+
        
        "</li>"+
        // "<li>"+
        // "<a class='qwe' href='/online-timesheet-software/modern/admin/settings/general-setting/'>Advance Setting</a>"+
        
        // "</li>"+



               
       
        " </li>"+
        "</ul>"+
        "</li>"+

        
       

       
       
    
        
        
        "</li>"+
        "</ul>"+
        "</ul>"+
        "</li>"+
        "</ul>"+
       
        "<li class='dropdownicon sidelist' title='Help'>" +
        "<a href='/online-timesheet-software/modern/admin/help/'>" +
        "Help" +
        "</a>" +
        "<img src='/online-timesheet-software/modern/admin/hdm-admin-aside-js/down-arrow-svgrepo-com.svg' class='imageIconadvanced aside_dropdown_icon' '>" +
        "</li>" +

        "<li data-nav-id='../advanced/' title=Help class='sidelist dropdown_romove_dot'>" +



        "<ul class='sidenavSub-topics aside_dropdown_list' id='modernsettingedm'>" +
        "<li  data-nav-id='../advanced/' title='Configure SharePoint API permissions' class='sidelist'>" +
        "<a href='/online-timesheet-software/modern/admin/help/#product-activation'>Product Activation</a>" +
        "</li>"  )
})
